"""Reachability on bitboards, for when the search runs it tens of thousands of times.

:func:`tetris_sdk.engine.reachable` is the readable reference: it works in
``Piece`` objects on a 40-row ``Board`` and costs a few milliseconds a call.
That is fine for inspecting one position and ruinous inside a bag-wide search,
which asks the same question for every stack it touches — the three-bag script
spent essentially all of its time there.

This is the same search over the same rules, with the board as one integer per
row and every orientation's column masks precomputed. Results are meant to
agree with the engine exactly; ``tests/test_fastreach.py`` checks that on random
stacks, and the engine stays the definition of correct.
"""

from __future__ import annotations

from collections import deque
from functools import lru_cache

from tetris_sdk.board import COLS
from tetris_sdk.engine import SpinType
from tetris_sdk.pieces import PieceType, SRS

_ROT_DELTA = {"cw": 1, "ccw": 3}


@lru_cache(maxsize=None)
def _shape(piece: PieceType, rotation: int) -> tuple:
    """Cells of an orientation, as offsets from the piece origin."""
    return tuple(SRS().rotations(piece)[rotation])


@lru_cache(maxsize=None)
def _kicks(piece: PieceType, frm: int, to: int) -> tuple:
    return tuple(SRS().kicks(piece, frm, to)) or ((0, 0),)


def _cells(piece: PieceType, rot: int, row: int, col: int) -> tuple:
    return tuple(sorted((row + dr, col + dc) for dr, dc in _shape(piece, rot)))


def _blocked(rows: tuple, cells: tuple) -> bool:
    """True if any cell is out of bounds or already filled."""
    for r, c in cells:
        if r < 0 or c < 0 or c >= COLS:
            return True
        if r < len(rows) and rows[r] >> c & 1:
            return True
    return False


def _filled(rows: tuple, r: int, c: int) -> bool:
    """Out of bounds counts as filled, matching the engine's corner rule."""
    if c < 0 or c >= COLS or r < 0:
        return True
    return r < len(rows) and bool(rows[r] >> c & 1)


def _immobile(rows: tuple, piece: PieceType, rot: int, row: int, col: int) -> bool:
    for dr, dc in ((1, 0), (-1, 0), (0, -1), (0, 1)):
        if not _blocked(rows, _cells(piece, rot, row + dr, col + dc)):
            return False
    return True


def _t_corners(rows: tuple, piece: PieceType, rot: int, row: int, col: int) -> int:
    cells = _cells(piece, rot, row, col)
    centre = next(
        (r, c) for r, c in cells
        if sum(abs(r - r2) + abs(c - c2) == 1 for r2, c2 in cells) == 3
    )
    return sum(
        _filled(rows, centre[0] + dr, centre[1] + dc)
        for dr in (-1, 1) for dc in (-1, 1)
    )


def _spin(rows: tuple, piece: PieceType, rot: int, row: int, col: int,
          rotated: bool) -> SpinType:
    """The engine's immobile convention, evaluated on bitboards."""
    if not rotated:
        return SpinType.NONE
    if piece is PieceType.T:
        if _t_corners(rows, piece, rot, row, col) >= 3:
            return (SpinType.FULL if _immobile(rows, piece, rot, row, col)
                    else SpinType.MINI)
        return SpinType.NONE
    return SpinType.FULL if _immobile(rows, piece, rot, row, col) else SpinType.NONE


@lru_cache(maxsize=None)
def reach(rows: tuple, piece: PieceType, instant: bool = False) -> dict:
    """``{locked cells: spin}`` for every placement reachable from spawn.

    ``instant`` models a soft drop that teleports to the floor, so descent is
    all-or-nothing and placements needing the piece halted partway are excluded.
    """
    top = len(rows)
    start = (0, top + 3, 3)
    if _blocked(rows, _cells(piece, *start)):
        return {}

    seen = {start: False}
    queue = deque([start])
    while queue:
        rot, row, col = state = queue.popleft()
        rotated = seen[state]

        moves = []
        for dc in (-1, 1):
            moves.append(((rot, row, col + dc), False))
        if instant:
            drop = row
            while not _blocked(rows, _cells(piece, rot, drop - 1, col)):
                drop -= 1
            if drop != row:
                moves.append(((rot, drop, col), False))
        else:
            moves.append(((rot, row - 1, col), False))
        for name, delta in _ROT_DELTA.items():
            to = (rot + delta) % 4
            for dr, dc in _kicks(piece, rot, to):
                cand = (to, row + dr, col + dc)
                if not _blocked(rows, _cells(piece, *cand)):
                    moves.append((cand, True))
                    break

        for nxt, is_rot in moves:
            if _blocked(rows, _cells(piece, *nxt)):
                continue
            if nxt in seen:
                if is_rot and not seen[nxt]:
                    seen[nxt] = True
                continue
            seen[nxt] = is_rot
            queue.append(nxt)

    out: dict = {}
    for (rot, row, col), rotated in seen.items():
        if not _blocked(rows, _cells(piece, rot, row - 1, col)):
            continue  # still falling
        cells = frozenset(_cells(piece, rot, row, col))
        spin = _spin(rows, piece, rot, row, col, rotated)
        if cells not in out or spin.rank > out[cells].rank:
            out[cells] = spin
    return out
