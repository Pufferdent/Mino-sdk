"""Opener research: boards, the lines between them, and their chances.

A node stores only what cannot be recomputed — a canonical fumen of the stack
and the pieces still to come. A line between two nodes is a whole bag of play,
searched with sfinder and replayed in the real frame. Everything else is
calculated: bag structure, clears, spins, gravity waits, and coverage over
queue space with hold.
"""

from tetris_sdk.opener.bridge import Bridge, LineClear, Route, Step
from tetris_sdk.opener.constraints import (
    Clears,
    Constraint,
    KeepB2B,
    NoGravityWait,
    Saves,
    Spin,
)
from tetris_sdk.opener.diagram import Diagram, Line, Odds
from tetris_sdk.opener.node import Node

__all__ = [
    "Node",
    "Bridge", "Route", "Step", "LineClear",
    "Diagram", "Line", "Odds",
    "Constraint", "KeepB2B", "Spin", "Saves", "NoGravityWait", "Clears",
]
