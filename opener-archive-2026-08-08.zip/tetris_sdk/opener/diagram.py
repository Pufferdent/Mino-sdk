"""A diagram: the boards you drew, the lines between them, and their chances.

This is the shape the work usually arrives in — a sequence of stacks sketched
out, each a bag apart, with something required of the play between them. Turn
each board into a fumen, name the lines, attach constraints, ask for the odds::

    d = Diagram()
    a, b, c = d.board(fumen_a), d.board(fumen_b), d.board(fumen_c)
    d.line(a, b, constraints=[KeepB2B()])
    d.line(b, c, constraints=[KeepB2B(), Spin(PieceType.T, lines=2)])
    d.chances()

Lines are not independent. Whatever a line leaves in hold is what the next line
starts holding, so the second chance is conditional on the first and
:meth:`Diagram.chances` reports the running product alongside each line.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from tetris_sdk.opener.bridge import Bridge
from tetris_sdk.opener.node import Node


@dataclass(frozen=True)
class Odds:
    """One line's result: its own chance, and the chance of reaching its end."""

    line: "Line"
    playable: int
    total: int

    @property
    def chance(self) -> float:
        return self.playable / self.total if self.total else 0.0


@dataclass
class Line:
    """A line of the diagram — one bag of play between two boards."""

    start: Node
    end: Node
    pieces: int = 7
    constraints: tuple = ()
    leftover: str = ""
    label: str = ""

    def bridge(self, jar: str | None = None) -> Bridge:
        return Bridge(
            start=self.start, end=self.end, pieces=self.pieces,
            constraint=self.leftover, constraints=tuple(self.constraints), jar=jar,
        )


@dataclass
class Diagram:
    """Boards and the lines between them."""

    lines: list = field(default_factory=list)
    jar: str | None = None

    def board(self, fumen: str) -> Node:
        """A board in the diagram, from the fumen you drew it as."""
        return Node(fumen, ())

    def line(
        self,
        start: Node,
        end: Node,
        *,
        pieces: int = 7,
        constraints=(),
        leftover: str = "",
        label: str = "",
    ) -> Line:
        line = Line(start, end, pieces, tuple(constraints), leftover, label)
        self.lines.append(line)
        return line

    def chances(self, per_tiling: int | None = None) -> list:
        """Each line's odds, in order.

        A line inherits the previous line's saved pieces as its leftover unless
        one was set explicitly, which is what makes these conditional.
        """
        out: list = []
        carried = ""
        for line in self.lines:
            if not line.leftover and carried:
                line.leftover = carried
            bridge = line.bridge(self.jar)
            routes = bridge.routes(per_tiling)
            playable, total = bridge.odds(per_tiling)
            out.append(Odds(line, playable, total))
            carried = "".join(p.name for p in routes[0].saved) if routes else ""
        return out

    def chained(self, per_tiling: int | None = None) -> float:
        """The chance of getting all the way through, as a running product."""
        product = 1.0
        for odds in self.chances(per_tiling):
            product *= odds.chance
        return product
