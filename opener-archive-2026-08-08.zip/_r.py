import time
from tetris_sdk.opener import Bridge, Node
F1='v115@zgh0EewwBeg0Eeywwhg0AtEehlwhBtR4BeRpglwhAtR4CeRpglwhJeAgH'
F2='v115@pgB8GeD8BeH8CeF8EeD8EeF8BeF8JeAgH'
F3='v115@fgA8IeA8IeC8FeD8CeF8DeG8BeH8CeD8JeAgH'
for name,a,b in [("pc-example","v115@vhAAgH","v115@UhC8DeA8BeD8MeAgH"),
                 ("bag1","v115@vhAAgH",F1),("bag2",F1,F2),("bag3",F2,F3)]:
    br=Bridge(Node(a,()),Node(b,()))
    t=time.perf_counter(); rs=br.routes()
    print(f"{name}: clears={br.cleared_lines} routes={len(rs)} ({time.perf_counter()-t:.1f}s)", flush=True)
