import time
from tetris_sdk.opener import Bridge, Node, KeepB2B
F1='v115@zgh0EewwBeg0Eeywwhg0AtEehlwhBtR4BeRpglwhAtR4CeRpglwhJeAgH'
b=Bridge(Node('v115@vhAAgH',()), Node(F1,()))
t=time.perf_counter(); rs=b.routes(); print(f"bag1 routes={len(rs)} ({time.perf_counter()-t:.1f}s)")
t=time.perf_counter(); h,n=b.odds(); print(f"bag1 chance={h}/{n}={h/n*100:.2f}% ({time.perf_counter()-t:.1f}s)")
