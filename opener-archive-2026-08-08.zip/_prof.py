import time, cProfile, pstats, io
from tetris_sdk.opener import Bridge, Node
from tetris_sdk.pieces import PieceType as P
br=Bridge(Node('v115@vhAAgH',()),Node('v115@UhC8DeA8BeD8MeAgH',()))
q=(P.L,P.J,P.Z,P.I,P.O,P.S,P.T)
t=time.perf_counter(); r=br.playable(q); dt=time.perf_counter()-t
print(f"one queue: {r} in {dt:.2f}s")
pr=cProfile.Profile(); pr.enable(); br.playable((P.T,P.I,P.L,P.J,P.S,P.Z,P.O)); pr.disable()
s=io.StringIO(); pstats.Stats(pr,stream=s).sort_stats('cumulative').print_stats(12)
print("\n".join(s.getvalue().splitlines()[:22]))
